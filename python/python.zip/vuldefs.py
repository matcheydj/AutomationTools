from lxml import etree
import os,sys,glob,re,codecs
from copy import deepcopy

xmlparser=etree.XMLParser(encoding='utf-8')
template=etree.parse("vul.bak",xmlparser)
vulEle=template.xpath("/GetVulnerabilitiesOfTypeResult/vulnerabilities/vulnerability")[0]
vulEleBak=deepcopy(vulEle)
vul_flag=0
for f in glob.glob('.\\linux\\V[a-zA-Z0-9_-]*.xml'):
  f0=etree.parse(f)
  status=f0.xpath("/Vulnerability/Status")[0].text
  if status=="Deleted":
    continue
  vul=vulEle
  if vul_flag>0:
    vul=deepcopy(vulEleBak)
  vul_flag+=1
  vul.set("Vul_ID",f0.xpath("@Vul_ID")[0])
  vul.set("CVE_ID",f0.xpath("@CVE_ID")[0])
  vulEle.getparent().append(vul)
  desc=f0.xpath("/Vulnerability/Description")[0].text
  vul.xpath("Title")[0].text=f0.xpath("/Vulnerability/Title")[0].text
  patches=f0.xpath("/Vulnerability/Patches/Patch")
  flag=0
  patchEle=vul.xpath("Patches/Patch")[0]
  for p in patches:
          element=patchEle
          if flag >0:
            element=deepcopy(patchEle)
          element.xpath("Name")[0].text=p.xpath("@UniqueFilename")[0]
          element.set("UniqueFilename",p.xpath("@UniqueFilename")[0])
          element.xpath("Files/File/Path")[0].text=p.xpath("Files/File/Path")[0].text
          element.xpath("Files/File/Checksum")[0].text=p.xpath("Files/File/Checksum")[0].text
          element.xpath("Files/File/Version")[0].text=p.xpath("Files/File/Version")[0].text
          element.xpath("Cmds/Cmd/Args/Arg")[0].set("V",p.xpath("Cmds/Cmd/Args/Arg/@V")[0].replace("\n","&#xA;").replace("\r","").replace("&>","&gt;&amp;").replace("\"","&quot;"))
          patchEle.getparent().append(element)
          flag+=1


prodEle=template.xpath("/GetVulnerabilitiesOfTypeResult/products/prod")[0]
prodEleBak=deepcopy(prodEle)
prod_flag=0
for p in glob.glob('.\\linux\\P[a-zA-Z0-9_-]*.xml'):
  p0=etree.parse(p)
  prod=prodEle
  if prod_flag>0:
    prod=deepcopy(prodEleBak)
  prod_flag+=1
  prod.set("Prod_ID",p0.xpath("@Prod_ID")[0])
  prod.xpath("Name")[0].text=p0.xpath("/PatchProductXML/Name")[0].text
  prod.xpath("DetectedByRPMs/RPM/filename")[0].text=p0.xpath("/PatchProductXML/DetectedByRPMs/RPM/filename")[0].text
  prod.xpath("DetectedByRPMs/RPM/minVersion")[0].text=p0.xpath("/PatchProductXML/DetectedByRPMs/RPM/minVersion")[0].text
  prod.xpath("DetectedByRPMs/RPM/maxVersion")[0].text=p0.xpath("/PatchProductXML/DetectedByRPMs/RPM/maxVersion")[0].text
  prodEle.getparent().append(prod)
  
  
template.write("temp.xml")

#  flag=0
#  if vendor is not None:
#    if re.search("LANDESK",vendor) is not None:
#      f0.xpath("/Vulnerability/Vendor")[0].text="Ivanti"
#      flag=1
#  if desc is not None:
#    if re.search("LANDESK",desc) is not None:
#      f0.xpath("/Vulnerability/Description")[0].text=re.sub("LANDESK","Ivanti",desc).strip()
#      flag=1
#  print(f)
#  if flag==1:
#      print(f)
#      patch0=f0.xpath("/Vulnerability/Patches/Patch")[0]
###      name=patch0.find("Name")
###      if patch0.find("SupercededBy") is not None:
###        patch0.find("SupercededBy").addnext(name)
#      vul=f0.xpath("/Vulnerability")[0]
#      patch0.attrib.pop("size",None)
#      if len(patch0.xpath("AdditionalFiles")) is not 0:
#  
#       patch0.remove(patch0.xpath("AdditionalFiles")[0])
#      if len(patch0.xpath("Processes")) is not 0:
#       patch0.remove(patch0.xpath("Processes")[0])
#      if len(vul.xpath("AssociatedProducts")) is not 0:
#       vul.remove(vul.xpath("AssociatedProducts")[0])
#      if len(vul.xpath("IAVAs")) is not 0:
#       vul.remove(vul.xpath("IAVAs")[0])
#      group=f0.find("Groups")
#      sta=f0.find("Status")
#      groupEle=etree.Element("Groups")
#      if group is None:
#       sta.addnext(groupEle)
#      depend=f0.find("DependsOn")
#      dependEle=etree.Element("DependsOn")
#      g=f0.find("Groups")
#      if  depend is None:
#       g.addnext(dependEle)
#      rev=f0.xpath("/Vulnerability/@Revision")[0]
#      rev=int(rev)+1
#      f0.xpath("/Vulnerability")[0].set("Revision",str(rev))
#      publish=f0.xpath("/Vulnerability/PublishDate")[0].text
#      
#      if re.search("\+00:00",publish) is not None:
#        newPublish=re.sub("\+00:00","",publish)
#        f0.xpath("/Vulnerability/PublishDate")[0].text=newPublish
#      new=re.sub('.\\\\mac\\\\',"",".\\\\dest\\\\"+f)
#      final=re.sub('.\\\\mac\\\\',"",".\\\\final\\\\"+f)
#      f0.write(new,encoding="utf8",xml_declaration=True,pretty_print=False)
#      with open(new,'r',encoding='utf-8') as f:
#        contents=f.read().replace('/>',' />').replace('<?xml version=\'1.0\' encoding=\'UTF8\'?>','<?xml version="1.0"?>').replace('+00:00','').replace("><",">\n  <").replace("xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"","xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"")
#        
#        with open(final,'w',encoding='utf-8') as fi:
#          fi.write(contents)
#        
